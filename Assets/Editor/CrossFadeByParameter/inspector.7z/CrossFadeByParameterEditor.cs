using UnityEditor;
using UnityEngine;
using UnityEditor.Animations;
using System.Collections.Generic;
using System;
using System.Reflection;

[CustomEditor(typeof(CrossFadeByParameter))]
public class CrossFadeByParameterEditor : Editor
{
    private SerializedProperty nextStateName;
    private SerializedProperty hasExitTime;
    private SerializedProperty exitTime;
    private SerializedProperty useFixedDuration;
    private SerializedProperty transitionOffset;
    private SerializedProperty transitionDuration;
    private SerializedProperty blendCurve;
    private SerializedProperty canBeInterrupted;
    private SerializedProperty conditions;

    private AnimatorController targetAnimatorController;
    private List<string> availableParameters = new List<string>();
    private bool isInitialized = false;
    // 添加当前控制器的检测字段
    private AnimatorController lastDetectedController;
    private int controllerCheckFrame = -1;

    // 启用时
    private void OnEnable()
    {
        // 获取关联的Animator信息
        GetAnimatorController();

        // 修复：检查目标对象是否有效
        if (targetAnimatorController == null)
        {
            Debug.LogWarning("获取AnimatorController失败");
            return;
        }
        try
        {
            // 延迟初始化，确保序列化对象可用
            EditorApplication.delayCall += InitializeEditor;
        }
        catch (System.Exception e)
        {
            Debug.LogWarning($"初始化CrossFadeByParameterEditor失败。: {e.Message}");
        }
    }

    // 初始化编辑器
    private void InitializeEditor()
    {
        if (isInitialized) return;
        try
        {
            // 修复：安全地获取序列化属性
            serializedObject.Update();

            nextStateName = serializedObject.FindProperty("nextStateName");
            hasExitTime = serializedObject.FindProperty("hasExitTime");
            exitTime = serializedObject.FindProperty("exitTime");
            useFixedDuration = serializedObject.FindProperty("useFixedDuration");
            transitionOffset = serializedObject.FindProperty("transitionOffset");
            transitionDuration = serializedObject.FindProperty("transitionDuration");
            blendCurve = serializedObject.FindProperty("blendCurve");
            canBeInterrupted = serializedObject.FindProperty("canBeInterrupted");
            conditions = serializedObject.FindProperty("conditions");

            // 验证属性是否成功获取
            if (nextStateName == null || hasExitTime == null)
            {
                Debug.LogError("未能找到所需的序列化属性");
                return;
            }

            GetAnimatorController();
            UpdateAvailableParameters();

            isInitialized = true;
        }
        catch (System.Exception e)
        {
            Debug.LogError($"初始化编辑器错误: {e.Message}");
        }
    }

    // 销毁组件时
    private void OnDisable()
    {
        // 清理延迟调用
        EditorApplication.delayCall -= InitializeEditor;
    }

    // 获取当前State所在的Animator Controller
    // 获取当前State所在的Animator Controller（仅编辑器环境，基于当前打开的Animator窗口）
    private AnimatorController GetAnimatorController()
    {
        targetAnimatorController = null;

        if (!(target is StateMachineBehaviour behaviour))
            return null;

        try
        {
            // 尝试从当前激活的Animator窗口获取控制器（编辑器专用）
            var animatorWindowType = Type.GetType("UnityEditor.Animations.AnimatorWindow, UnityEditor");
            if (animatorWindowType != null)
            {
                // 获取当前激活的Animator窗口实例
                var getActiveWindowMethod = animatorWindowType.GetMethod("GetActiveWindow", BindingFlags.Static | BindingFlags.Public);
                if (getActiveWindowMethod != null)
                {
                    var activeWindow = getActiveWindowMethod.Invoke(null, null);
                    if (activeWindow != null)
                    {
                        // 获取窗口中当前编辑的控制器
                        var controllerProperty = animatorWindowType.GetProperty("animatorController", BindingFlags.Instance | BindingFlags.Public);
                        if (controllerProperty != null)
                        {
                            var currentController = controllerProperty.GetValue(activeWindow) as AnimatorController;
                            if (currentController != null)
                            {
                                // 验证当前行为是否属于这个控制器
                                if (IsBehaviourInController(behaviour, currentController))
                                {
                                    targetAnimatorController = currentController;
                                    Debug.Log($"✅ 从Animator窗口获取到控制器: {targetAnimatorController.name}");
                                    return targetAnimatorController;
                                }
                            }
                        }
                    }
                }
            }

            // 备选方案：从行为的序列化数据中获取
            SerializedObject serializedBehaviour = new SerializedObject(behaviour);
            SerializedProperty controllerProp = serializedBehaviour.FindProperty("m_Controller");
            if (controllerProp != null && controllerProp.objectReferenceValue is AnimatorController serialiedController)
            {
                targetAnimatorController = serialiedController;
                Debug.Log($"✅ 从序列化数据获取到控制器: {targetAnimatorController.name}");
                return targetAnimatorController;
            }

            Debug.LogWarning("❌ 无法获取Animator Controller，请确保Animator窗口已打开并选择了正确的控制器");
            return null;
        }
        catch (System.Exception e)
        {
            Debug.LogError($"获取Animator Controller时发生错误: {e.Message}");
            return null;
        }
    }

    // 验证行为是否属于指定控制器
    private bool IsBehaviourInController(StateMachineBehaviour behaviour, AnimatorController controller)
    {
        if (behaviour == null || controller == null) return false;

        // 检查所有层的状态机
        foreach (var layer in controller.layers)
        {
            if (CheckStateMachineForBehaviour(layer.stateMachine, behaviour))
            {
                return true;
            }
        }
        return false;
    }

    // 递归检查状态机中是否包含目标行为
    private bool CheckStateMachineForBehaviour(AnimatorStateMachine stateMachine, StateMachineBehaviour behaviour)
    {
        if (stateMachine == null) return false;

        // 检查当前状态机的所有状态
        foreach (var state in stateMachine.states)
        {
            foreach (var behaviourInState in state.state.behaviours)
            {
                if (behaviourInState == behaviour)
                {
                    return true;
                }
            }
        }

        // 递归检查子状态机
        foreach (var childMachine in stateMachine.stateMachines)
        {
            if (CheckStateMachineForBehaviour(childMachine.stateMachine, behaviour))
            {
                return true;
            }
        }

        return false;
    }


    // 更新当前控制器中可用参数库（优化版本）
    private void UpdateAvailableParameters()
    {
        availableParameters.Clear();
        availableParameters.Add(""); // 空选项

        // 使用实时获取的控制器，而不是缓存的
        AnimatorController currentController = GetAnimatorController();

        if (currentController != null)
        {
            try
            {
                if (currentController.parameters == null)
                {
                    Debug.LogWarning($"控制器 '{currentController.name}' 的参数数组为null");
                    return;
                }

                int paramCount = currentController.parameters.Length;

                if (paramCount == 0)
                {
                    Debug.LogWarning($"控制器 '{currentController.name}' 没有任何参数");
                    return;
                }

                int addedCount = 0;
                for (int i = 0; i < paramCount; i++)
                {
                    var param = currentController.parameters[i];

                    if (IsValidParameter(param))
                    {
                        if (!availableParameters.Contains(param.name))
                        {
                            availableParameters.Add(param.name);
                            addedCount++;
                        }
                    }
                }

                if (addedCount > 0)
                {
                    Debug.Log($"从控制器 '{currentController.name}' 成功加载 {addedCount} 个参数");
                    availableParameters.Sort();
                }

                // 更新缓存引用
                targetAnimatorController = currentController;
            }
            catch (System.Exception e)
            {
                Debug.LogError($"从控制器获取参数失败: {e.Message}");
            }
        }
        else
        {
            Debug.LogWarning("无法获取当前Animator Controller引用");
        }
    }

    // 验证参数有效性
    private bool IsValidParameter(AnimatorControllerParameter param)
    {
        if (param == null)
            return false;
        
        if (string.IsNullOrEmpty(param.name))
            return false;
        
        if (param.name.Trim().Length == 0)
            return false;
        
        // 检查参数名是否包含非法字符
        if (ContainsInvalidCharacters(param.name))
            return false;
        
        return true;
    }

    // 检查非法字符
    private bool ContainsInvalidCharacters(string paramName)
    {
        char[] invalidChars = { '<', '>', ':', '"', '/', '\\', '|', '?', '*' };
        return paramName.IndexOfAny(invalidChars) >= 0;
    }

    // 获取参数详细信息（用于调试）
    private void LogParameterDetails()
    {
        if (targetAnimatorController == null || targetAnimatorController.parameters == null)
            return;
        
        Debug.Log($"控制器 '{targetAnimatorController.name}' 参数详情:");
        for (int i = 0; i < targetAnimatorController.parameters.Length; i++)
        {
            var param = targetAnimatorController.parameters[i];
            Debug.Log($"  [{i}] {param.name} ({param.type}) - Default: {GetParameterDefaultValue(param)}");
        }
    }

    // 获取参数默认值
    private string GetParameterDefaultValue(AnimatorControllerParameter param)
    {
        if (param == null) return "null";
        
        switch (param.type)
        {
            case AnimatorControllerParameterType.Float:
                return param.defaultFloat.ToString("F2");
            case AnimatorControllerParameterType.Int:
                return param.defaultInt.ToString();
            case AnimatorControllerParameterType.Bool:
                return param.defaultBool.ToString();
            case AnimatorControllerParameterType.Trigger:
                return "Trigger";
            default:
                return "Unknown";
        }
    }

    // 检查参数是否存在
    public bool HasParameter(string parameterName)
    {
        if (targetAnimatorController == null || string.IsNullOrEmpty(parameterName))
            return false;
        
        try
        {
            for (int i = 0; i < targetAnimatorController.parameters.Length; i++)
            {
                if (targetAnimatorController.parameters[i].name == parameterName)
                    return true;
            }
        }
        catch (Exception e)
        {
            Debug.LogWarning($"检查参数存在性失败: {e.Message}");
        }
        
        return false;
    }

    // 添加专门查找State所属控制器的方法
    private AnimatorController FindParentControllerForState(AnimatorState targetState)
    {
        if (targetState == null) return null;

        // 查找所有Animator Controller
        string[] controllerGUIDs = AssetDatabase.FindAssets("t:AnimatorController");
        foreach (string guid in controllerGUIDs)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            AnimatorController controller = AssetDatabase.LoadAssetAtPath<AnimatorController>(path);
            if (controller != null && ContainsState(controller, targetState))
            {
                return controller;
            }
        }

        return null;
    }

    // 检查控制器是否包含指定State
    private bool ContainsState(AnimatorController controller, AnimatorState targetState)
    {
        if (controller == null || targetState == null) return false;

        foreach (AnimatorControllerLayer layer in controller.layers)
        {
            if (ContainsStateInStateMachine(layer.stateMachine, targetState))
            {
                return true;
            }
        }

        return false;
    }

    // 递归检查StateMachine中的State
    private bool ContainsStateInStateMachine(AnimatorStateMachine stateMachine, AnimatorState targetState)
    {
        if (stateMachine == null || targetState == null) return false;

        // 检查当前StateMachine的状态
        foreach (ChildAnimatorState state in stateMachine.states)
        {
            if (state.state == targetState)
                return true;
        }

        // 递归检查子StateMachine
        foreach (ChildAnimatorStateMachine childMachine in stateMachine.stateMachines)
        {
            if (ContainsStateInStateMachine(childMachine.stateMachine, targetState))
                return true;
        }

        return false;
    }
    // 添加控制器变化检测方法
    private void CheckControllerChanged()
    {
        // 避免每帧都检测，提高性能
        if (Time.frameCount == controllerCheckFrame) return;

        controllerCheckFrame = Time.frameCount;

        AnimatorController currentController = GetAnimatorController();
        if (currentController != lastDetectedController)
        {
            Debug.Log($"检测到控制器变化: {lastDetectedController?.name} -> {currentController?.name}");
            lastDetectedController = currentController;
            targetAnimatorController = currentController;
            UpdateAvailableParameters();
        }
    }

    // 绘制inspector UI
    public override void OnInspectorGUI()
    {
        // 修复：每次绘制前检查控制器是否发生变化
        CheckControllerChanged();

        // 修复：检查初始化状态
        if (!isInitialized)
        {
            EditorGUILayout.HelpBox("编辑器未正确初始化。请重新选择对象。", MessageType.Error);
            if (GUILayout.Button("重试初始化"))
            {
                InitializeEditor();
            }
            return;
        }

        if (serializedObject == null || target == null)
        {
            EditorGUILayout.HelpBox("序列化对象为空。该组件可能已被删除。", MessageType.Error);
            return;
        }

        serializedObject.Update();
        
        EditorGUI.BeginChangeCheck();
        
        try
        {
            // 1. 设置区域
            DrawSettingsSection();
            // 3. 混合设置区域
            DrawMixSettingsSection();
            // 4. 转换控制
            DrawTransitionControlSection();
            // 2. 条件区域
            DrawConditionsSection();
        }
        catch (System.Exception e)
        {
            EditorGUILayout.HelpBox($"绘制UI错误: {e.Message}", MessageType.Error);
        }
        
        if (EditorGUI.EndChangeCheck())
        {
            serializedObject.ApplyModifiedProperties();
        }

        // 刷新按钮
        EditorGUILayout.Space();
        //if (GUILayout.Button("刷新参数"))
        //{
        //    GetAnimatorController();
        //    UpdateAvailableParameters();
        //    Repaint();
        //}
        DrawRefreshButton();
    }

    // 修改刷新按钮的回调
    private void DrawRefreshButton()
    {
        EditorGUILayout.Space();
        if (GUILayout.Button("刷新参数"))
        {
            // 强制刷新控制器和参数
            lastDetectedController = null;
            controllerCheckFrame = -1;
            UpdateAvailableParameters();
            Repaint();
        }
        
        // 添加当前控制器显示
        AnimatorController currentController = GetAnimatorController();
        if (currentController != null)
        {
            EditorGUILayout.LabelField($"当前控制器: {currentController.name}", EditorStyles.miniLabel);
        }
        else
        {
            EditorGUILayout.LabelField("当前控制器: 未找到", EditorStyles.miniLabel);
        }
    }


    private void DrawSettingsSection()
    {
        if (nextStateName == null || hasExitTime == null)
        {
            EditorGUILayout.EndVertical();
            return;
        }
        
        EditorGUILayout.LabelField("过渡设置", EditorStyles.boldLabel);
        
        EditorGUILayout.BeginVertical(GUI.skin.box);
        {
            EditorGUILayout.PropertyField(nextStateName, new GUIContent("目标状态名"));
            EditorGUILayout.PropertyField(hasExitTime, GUILayout.Width(120));


            if (hasExitTime.boolValue && useFixedDuration != null)
            {
                EditorGUILayout.PropertyField(useFixedDuration, new GUIContent("固定时间"));
            }
            
            EditorGUILayout.BeginHorizontal();
            if (hasExitTime.boolValue)
            {
                EditorGUILayout.PropertyField(exitTime, new GUIContent("混出位置"));
                EditorGUILayout.LabelField(useFixedDuration.boolValue ? "s" : "%", GUILayout.Width(15));
            }
            EditorGUILayout.EndHorizontal();
            
            
        }
        EditorGUILayout.EndVertical();
        
        EditorGUILayout.Space();
    }

    private void DrawConditionsSection()
    {
        if (conditions == null) return;
        
        EditorGUILayout.LabelField("转换条件", EditorStyles.boldLabel);
        
        EditorGUILayout.BeginVertical(GUI.skin.box);
        {
            // 显示实时获取的控制器信息
            AnimatorController currentController = GetAnimatorController();
            if (currentController != null)
            {
                EditorGUILayout.LabelField($"使用: {currentController.name}", EditorStyles.miniLabel);
            }
            else
            {
                EditorGUILayout.HelpBox("没有找到动画控制器。", MessageType.Warning);
            }

            if (conditions.arraySize == 0)
            {
                EditorGUILayout.HelpBox("无条件", MessageType.Info);
            }
            else
            {
                for (int i = 0; i < conditions.arraySize; i++)
                {
                    var condition = conditions.GetArrayElementAtIndex(i);
                    if (condition != null)
                    {
                        DrawConditionRow(condition, i);
                        // 每行上下间隔
                        // if (i < conditions.arraySize - 1)
                        // {
                        //     EditorGUILayout.Separator();
                        // }
                    }
                }
            }
            
            EditorGUILayout.BeginHorizontal();
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("+", GUILayout.Width(30)))
            {
                conditions.arraySize++;
                serializedObject.ApplyModifiedProperties();
            }
            EditorGUILayout.EndHorizontal();
        }
        EditorGUILayout.EndVertical();
        
        EditorGUILayout.Space();
    }

    // 绘制一行条件
    private void DrawConditionRow(SerializedProperty condition, int index)
    {
        if (condition == null) return;

        // 修复：正确的属性查找方式
        SerializedProperty parameterProp = condition.FindPropertyRelative("parameter");
        SerializedProperty modeProp = condition.FindPropertyRelative("mode");
        SerializedProperty thresholdProp = condition.FindPropertyRelative("threshold");

        if (parameterProp == null || modeProp == null || thresholdProp == null)
        {
            Debug.LogError("无法找到条件属性");
            return;
        }

        EditorGUILayout.BeginHorizontal();
        {
            DrawParameterField(parameterProp);

            string parameterName = parameterProp.stringValue ?? "";
            AnimatorControllerParameterType paramType = GetParameterType(parameterName);

            // 修复：传入正确的参数
            DrawModeField(modeProp, paramType);

            DrawThresholdField(thresholdProp, parameterName);

            GUILayout.FlexibleSpace();
            if (GUILayout.Button("-", GUILayout.Width(20)))
            {
                conditions.DeleteArrayElementAtIndex(index);
                serializedObject.ApplyModifiedProperties();
                return;
            }
        }
        EditorGUILayout.EndHorizontal();
    }

    // 检查属性是否为枚举类型
    private bool IsEnumProperty(SerializedProperty prop)
    {
        return prop != null && prop.propertyType == SerializedPropertyType.Enum;
    }

    // 绘制模式字段（根据您的枚举定义修改）
    private void DrawModeField(SerializedProperty modeProp, AnimatorControllerParameterType paramType)
    {

        if (modeProp == null || !IsEnumProperty(modeProp)) return;
        
        // 确保枚举值在有效范围内（0-3对应您的枚举值）
        int enumCount = Enum.GetValues(typeof(CompareOperator)).Length;
        if (modeProp.enumValueIndex < 0 || modeProp.enumValueIndex >= enumCount)
        {
            modeProp.enumValueIndex = (int)CompareOperator.Equals;
        }
        
        switch (paramType)
        {
            case AnimatorControllerParameterType.Trigger:
                return; // 不绘制
                
            case AnimatorControllerParameterType.Bool:
                DrawBoolModeField(modeProp);
                break;
                
            case AnimatorControllerParameterType.Float:
            case AnimatorControllerParameterType.Int:
                DrawNumericModeField(modeProp);
                break;
                
            default:
                DrawDefaultModeField(modeProp);
                break;
        }
    }

    // Bool类型的模式选择（根据您的枚举定义修改）
    private void DrawBoolModeField(SerializedProperty modeProp)
    {
        if (modeProp == null || !IsEnumProperty(modeProp)) return;
        
        string[] boolModeSymbols = { "==" };
        
        // 强制设置为等于操作符（根据您的枚举定义）
        if (modeProp.enumValueIndex != (int)CompareOperator.Equals)
        {
            modeProp.enumValueIndex = (int)CompareOperator.Equals;
        }
        
        // 显示只读的等于操作符
        EditorGUI.BeginDisabledGroup(true);
        EditorGUILayout.Popup(0, boolModeSymbols, GUILayout.Width(50));
        EditorGUI.EndDisabledGroup();
    }

    // 数值类型的模式选择（根据您的枚举定义修改）
    private void DrawNumericModeField(SerializedProperty modeProp)
    {
        if (modeProp == null || !IsEnumProperty(modeProp)) return;
        
        string[] numericModeSymbols = { ">", "<", "==", "!=" };
        
        // 确保选择的是有效模式（0-3对应您的枚举值）
        int selectedMode = Mathf.Clamp(modeProp.enumValueIndex, 0, numericModeSymbols.Length - 1);
        
        int newMode = EditorGUILayout.Popup(selectedMode, numericModeSymbols, GUILayout.Width(50));
        
        if (newMode != selectedMode && newMode >= 0 && newMode < numericModeSymbols.Length)
        {
            modeProp.enumValueIndex = newMode;
        }
    }

    // 默认模式选择（根据您的枚举定义修改）
    private void DrawDefaultModeField(SerializedProperty modeProp)
    {
        if (modeProp == null || !IsEnumProperty(modeProp)) return;
        
        string[] modeSymbols = { ">", "<", "==", "!=" };
        
        // 确保选择的是有效模式（0-3对应您的枚举值）
        int selectedMode = Mathf.Clamp(modeProp.enumValueIndex, 0, modeSymbols.Length - 1);
        
        int newMode = EditorGUILayout.Popup(selectedMode, modeSymbols, GUILayout.Width(50));
        
        if (newMode != selectedMode && newMode >= 0 && newMode < modeSymbols.Length)
        {
            modeProp.enumValueIndex = newMode;
        }
    }

    // 绘制参数选择字段
    private void DrawParameterField(SerializedProperty parameterProp)
    {
        if (parameterProp == null || availableParameters == null) return;
        
        int selectedIndex = 0;
        string currentParam = parameterProp.stringValue ?? "";
        
        // 查找当前选择的参数索引
        for (int i = 0; i < availableParameters.Count; i++)
        {
            if (availableParameters[i] == currentParam)
            {
                selectedIndex = i;
                break;
            }
        }
        
        // 绘制参数下拉选择框
        int newIndex = EditorGUILayout.Popup(selectedIndex, availableParameters.ToArray(), GUILayout.Width(120));
        
        if (newIndex >= 0 && newIndex < availableParameters.Count)
        {
            parameterProp.stringValue = availableParameters[newIndex];
        }
    }
    // 获取参数类型
    private AnimatorControllerParameterType GetParameterType(string parameterName)
    {
        if (string.IsNullOrEmpty(parameterName) || targetAnimatorController == null)
            return AnimatorControllerParameterType.Float;
        
        try
        {
            for (int i = 0; i < targetAnimatorController.parameters.Length; i++)
            {
                var param = targetAnimatorController.parameters[i];
                if (param.name == parameterName)
                    return param.type;
            }
        }
        catch (Exception e)
        {
            Debug.LogWarning($"获取参数类型失败: {e.Message}");
        }
        
        return AnimatorControllerParameterType.Float;
    }

    

    private void DrawThresholdField(SerializedProperty thresholdProp, string parameterName)
    {
        if (thresholdProp == null) return;
        
        if (string.IsNullOrEmpty(parameterName))
        {
            EditorGUILayout.PropertyField(thresholdProp, GUIContent.none);
            return;
        }
        
        try
        {
            var paramType = GetParameterType(parameterName);//
            switch (paramType)
            {
                case AnimatorControllerParameterType.Float:
                    thresholdProp.floatValue = EditorGUILayout.FloatField(thresholdProp.floatValue);
                    break;
                case AnimatorControllerParameterType.Int:
                    thresholdProp.floatValue = EditorGUILayout.IntField((int)thresholdProp.floatValue);
                    break;
                case AnimatorControllerParameterType.Bool:
                    bool currentBool = thresholdProp.floatValue > 0.5f;
                    bool newBool = EditorGUILayout.Toggle(currentBool);
                    thresholdProp.floatValue = newBool ? 1f : 0f;
                    break;
                case AnimatorControllerParameterType.Trigger:
                    EditorGUILayout.LabelField("(Trigger)", GUILayout.Width(60));
                    break;
                default:
                    EditorGUILayout.PropertyField(thresholdProp, GUIContent.none);
                    break;
            }
        }
        catch (System.Exception e)
        {
            Debug.LogWarning($"错误绘制阈值字段: {e.Message}");
            EditorGUILayout.PropertyField(thresholdProp, GUIContent.none);
        }
    }

    private void DrawMixSettingsSection()
    {
        if (transitionOffset == null || transitionDuration == null || blendCurve == null) return;
        
        EditorGUILayout.LabelField("混合设置", EditorStyles.boldLabel);
        
        EditorGUILayout.BeginVertical(GUI.skin.box);
        {
            EditorGUILayout.PropertyField(transitionOffset, new GUIContent("过渡偏移"));
            EditorGUILayout.PropertyField(transitionDuration, new GUIContent("过度时间"));
            EditorGUILayout.PropertyField(blendCurve, new GUIContent("混合曲线"));
        }
        EditorGUILayout.EndVertical();
        
        EditorGUILayout.Space();
    }

    private void DrawTransitionControlSection()
    {
        if (canBeInterrupted == null) return;
        
        EditorGUILayout.LabelField("过渡控制", EditorStyles.boldLabel);
        
        EditorGUILayout.BeginVertical(GUI.skin.box);
        {
            EditorGUILayout.PropertyField(canBeInterrupted, new GUIContent("允许打断"));
        }
        EditorGUILayout.EndVertical();
    }
}